package com.pgmacdesign.journalreadingofwallstreet;

public interface RefreshableInterface {
	public void startFresh();
	public void startLoadMore();
}
