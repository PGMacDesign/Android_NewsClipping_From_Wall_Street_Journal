package com.pgmacdesign.journalreadingofwallstreet;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class TEST {

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * 
	 ListView listView1 = (ListView) rootView.findViewById(R.id.autos_list);
		
		Product[] items = { 
	            new Product(1, "Milk", 21.50), 
	            new Product(2, "Butter", 15.99), 
	            new Product(3, "Yogurt", 14.90), 
	            new Product(4, "Toothpaste", 7.99), 
	            new Product(5, "Ice Cream", 10.00), 
	        };
		
		mRssFeed = (ListView) rootView.findViewById(R.id.listView1);
		
		ArrayAdapter<Product> adapter = new ArrayAdapter<Product>(this,
                android.R.layout.simple_list_item_1, items);
	    
	    listView1.setAdapter(adapter);
	
	    listView1.setOnItemClickListener(new OnItemClickListener() {
	        @Override
	        public void onItemClick(AdapterView<?> parent, View view, int position,
	                long id) {
	            
	            String item = ((TextView)view).getText().toString();
	            
	            Toast.makeText(getActivity().getApplicationContext(), item, Toast.LENGTH_LONG).show();
	            
	        }

	    });		
	    
	    
	    	    //To parse the xml
	    XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        XmlPullParser xpp = factory.newPullParser();
        
        
        
            public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
        
        
        
        	//For the options menu
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.
    	MenuInflater inflater = getActivity().getMenuInflater();

        return true;
    }
    
    //
    }
    
    
        
	 */
}
